//Tap Controller Page

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class ButtonTap : MonoBehaviour {

  public float tapStrength = 0;
  public float downTilt = 0;  //player rotates downwards as he falls
  public Vector3 startPos; //when we reset the game, when are we going to set the bird back too


  Rigidbody2D rigidbody;
  Quaternion  downRotation;//way of basically having a secure location Quaternion is a fancy form of location.
  Quaternion upwardRotation; //everytime we tap were going to come back to this.

  void Start() { //defining some of these values
    rigidbody = GetComponent<Rigidbody2D>(); //gets the component off of our object
    downRotation = Quaternion.Euler(0, 0, -60); //putting him face down,
    upwardRotation = Quaternion.Euler(0, 0, 35); //were taking a vector 3 and converting that into a quaternion

  }

  void Update() {
    if (Input.GetMouseButtonDown(0)) { //this translate perfectly 0 indicates left click, This translates perfectly as a tap notification on mobile devices
    transform.rotation = upwardRotation;
    rigidbody.AddForce(Vector2.up * tapStrength, ForceMode2D.Force); //this is the default Force Mode
 
    }
    transform.rotation = Quaternion.Lerp(transform.rotation, downRotation, downTilt * Time.deltaTime); // were going to a source value from a target value in a certain amount of time
  }
}